## Getting started on [CoreOS](http://coreos.com)

There are multiple guides on running Kubernetes with [CoreOS](http://coreos.com):

[Single Kubernetes example in any environment](http://coreos.com/blog/running-kubernetes-example-on-CoreOS-part-1/)

[Multiple host example using VMware Fusion](http://coreos.com/blog/running-kubernetes-example-on-CoreOS-part-2/)
