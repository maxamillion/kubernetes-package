# go-etcd

The official etcd v0.2 client library for Go.

For usage, please refer to [![GoDoc](https://godoc.org/github.com/coreos/go-etcd/etcd?status.png)](https://godoc.org/github.com/coreos/go-etcd/etcd)

## Install

```bash
go get github.com/coreos/go-etcd/etcd
```

## License

See LICENSE file.
