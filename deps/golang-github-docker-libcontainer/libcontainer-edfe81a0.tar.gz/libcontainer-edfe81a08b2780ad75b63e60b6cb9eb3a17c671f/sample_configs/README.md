These configuration files can be used with `nsinit` to quickly develop, test,
and experiment with features of libcontainer.

When consuming these configuration files, copy them into your rootfs and rename
the file to `container.json` for use with `nsinit`.
